package com.example.worldcup;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.Set;

public class MainActivity extends AppCompatActivity {
    ArrayList<ImageView> imgList=new ArrayList<ImageView>();
    ArrayList<Button> btnList=new ArrayList<Button>();
    ArrayList<TextView> textList=new ArrayList<TextView>();
    Intent intent;
    com.example.worldcup.Set set = new com.example.worldcup.Set();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imgSetting();
        btnSetting();
        textSetting();
        imgClickSetting();
        btnClickSetting();
    }
    private void imgSetting() {
        imgList.add(findViewById(R.id.img1));
        imgList.add(findViewById(R.id.img2));
        imgList.add(findViewById(R.id.img3));
    }

    private void btnSetting() {
        btnList.add(findViewById(R.id.back));
        btnList.add(findViewById(R.id.top4));
        btnList.add(findViewById(R.id.top8));
        btnList.add(findViewById(R.id.top16));
    }
    private void textSetting() {
        textList.add(findViewById(R.id.text1));
        textList.add(findViewById(R.id.text2));
        textList.add(findViewById(R.id.text3));
    }
    private void imgClickSetting() {
        imgList.get(0).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                set.topic=1;
                for(int i=0;i<imgList.size();i++){
                    imgList.get(i).setVisibility(View.GONE);
                }
                for(int i=0;i<btnList.size();i++){
                    btnList.get(i).setVisibility(View.VISIBLE);
                }
                for(int i=0;i<textList.size();i++){
                    textList.get(i).setVisibility(View.GONE);
                }
            }
        });
        imgList.get(1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                set.topic=2;
                for(int i=0;i<imgList.size();i++){
                    imgList.get(i).setVisibility(View.GONE);
                }
                for(int i=0;i<btnList.size();i++){
                    btnList.get(i).setVisibility(View.VISIBLE);
                }
                for(int i=0;i<textList.size();i++){
                    textList.get(i).setVisibility(View.GONE);
                }
            }
        });
        imgList.get(2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                set.topic=3;
                for(int i=0;i<imgList.size();i++){
                    imgList.get(i).setVisibility(View.GONE);
                }
                for(int i=0;i<btnList.size();i++){
                    btnList.get(i).setVisibility(View.VISIBLE);
                }
                for(int i=0;i<textList.size();i++){
                    textList.get(i).setVisibility(View.GONE);
                }
            }
        });
    }
    private void btnClickSetting() {
        btnList.get(0).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                for(int i=0;i<imgList.size();i++){
                    imgList.get(i).setVisibility(View.VISIBLE);
                }
                for(int i=0;i<btnList.size();i++){
                    btnList.get(i).setVisibility(View.GONE);
                }
            }
        });
        btnList.get(1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                set.top=4;
                intent = new Intent(getApplicationContext(), CupActivity.class);
                intent.putExtra("set", set);
                startActivity(intent);
            }
        });
        btnList.get(2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                set.top=8;
                intent = new Intent(getApplicationContext(), CupActivity.class);
                intent.putExtra("set", set);
                startActivity(intent);
            }
        });
        btnList.get(3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                set.top=16;
                intent = new Intent(getApplicationContext(), CupActivity.class);
                intent.putExtra("set", set);
                startActivity(intent);
            }
        });
    }
}