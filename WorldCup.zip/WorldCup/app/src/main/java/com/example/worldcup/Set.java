package com.example.worldcup;

import java.io.Serializable;

public class Set implements Serializable {
    int topic,top;
}
