package com.example.worldcup;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.Random;

public class CupActivity extends AppCompatActivity {
    ArrayList<ImageView> imgList = new ArrayList<ImageView>();
    ArrayList<Drawable> soccerList = new ArrayList<Drawable>();
    ArrayList<Drawable> chamList = new ArrayList<Drawable>();
    ArrayList<Drawable> playerList = new ArrayList<Drawable>();
    ArrayList<Drawable> drawList = new ArrayList<Drawable>();
    ArrayList<Drawable> top16List = new ArrayList<Drawable>();
    ArrayList<Drawable> top8List = new ArrayList<Drawable>();
    ArrayList<Drawable> top4List = new ArrayList<Drawable>();
    ArrayList<Drawable> top2List = new ArrayList<Drawable>();
    ArrayList<Drawable> top1List = new ArrayList<Drawable>();
    TextView text,text2;
    Button button;
    Intent intent;
    Random random = new Random();
    Set set;
    int top16round=0;
    int top8round=0;
    int top4round=0;
    int top2round=0;
    int top1round=0;
    int first = 0;// drawList에서 topList에 넣는 행위가 처음인지 아닌지

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cup);
        setting();
        imgSetting();
        textSetting();
        buttonSetting();
        listSetting();
        Start();
        /*imgList.add(findViewById(R.id.img1));
        imgList.add(findViewById(R.id.img2));

        top16List.add(imgList.get(0).getDrawable());
        imgList.get(1).setImageDrawable(top16List.get(0));*/
    }

    private void setting() {
        Intent intent = getIntent();
        set = (Set) intent.getSerializableExtra("set");

    }

    private void imgSetting() {
        imgList.add(findViewById(R.id.img1));
        imgList.add(findViewById(R.id.img2));
    }
    private void buttonSetting() {
        button=findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });
    }
    private void textSetting() {
        text=findViewById(R.id.text);
        text2=findViewById(R.id.text2);
    }
    private void listSetting() {
        soccerList.add(getResources().getDrawable(R.drawable.soccer1));
        soccerList.add(getResources().getDrawable(R.drawable.soccer2));
        soccerList.add(getResources().getDrawable(R.drawable.soccer3));
        soccerList.add(getResources().getDrawable(R.drawable.soccer4));
        soccerList.add(getResources().getDrawable(R.drawable.soccer5));
        soccerList.add(getResources().getDrawable(R.drawable.soccer6));
        soccerList.add(getResources().getDrawable(R.drawable.soccer7));
        soccerList.add(getResources().getDrawable(R.drawable.soccer8));
        soccerList.add(getResources().getDrawable(R.drawable.soccer9));
        soccerList.add(getResources().getDrawable(R.drawable.soccer10));
        soccerList.add(getResources().getDrawable(R.drawable.soccer11));
        soccerList.add(getResources().getDrawable(R.drawable.soccer12));
        soccerList.add(getResources().getDrawable(R.drawable.soccer13));
        soccerList.add(getResources().getDrawable(R.drawable.soccer14));
        soccerList.add(getResources().getDrawable(R.drawable.soccer15));
        soccerList.add(getResources().getDrawable(R.drawable.soccer16));

        chamList.add(getResources().getDrawable(R.drawable.soccer1));
        chamList.add(getResources().getDrawable(R.drawable.soccer2));
        chamList.add(getResources().getDrawable(R.drawable.soccer3));
        chamList.add(getResources().getDrawable(R.drawable.soccer5));
        chamList.add(getResources().getDrawable(R.drawable.soccer9));
        chamList.add(getResources().getDrawable(R.drawable.soccer10));
        chamList.add(getResources().getDrawable(R.drawable.soccer11));
        chamList.add(getResources().getDrawable(R.drawable.soccer13));
        chamList.add(getResources().getDrawable(R.drawable.soccer16));
        chamList.add(getResources().getDrawable(R.drawable.cham1));
        chamList.add(getResources().getDrawable(R.drawable.cham2));
        chamList.add(getResources().getDrawable(R.drawable.cham3));
        chamList.add(getResources().getDrawable(R.drawable.cham4));
        chamList.add(getResources().getDrawable(R.drawable.cham5));
        chamList.add(getResources().getDrawable(R.drawable.cham6));
        chamList.add(getResources().getDrawable(R.drawable.cham7));

        playerList.add(getResources().getDrawable(R.drawable.player1));
        playerList.add(getResources().getDrawable(R.drawable.player2));
        playerList.add(getResources().getDrawable(R.drawable.player3));
        playerList.add(getResources().getDrawable(R.drawable.player4));
        playerList.add(getResources().getDrawable(R.drawable.player5));
        playerList.add(getResources().getDrawable(R.drawable.player6));
        playerList.add(getResources().getDrawable(R.drawable.player7));
        playerList.add(getResources().getDrawable(R.drawable.player8));
        playerList.add(getResources().getDrawable(R.drawable.player9));
        playerList.add(getResources().getDrawable(R.drawable.player10));
        playerList.add(getResources().getDrawable(R.drawable.player11));
        playerList.add(getResources().getDrawable(R.drawable.player12));
        playerList.add(getResources().getDrawable(R.drawable.player13));
        playerList.add(getResources().getDrawable(R.drawable.player14));
        playerList.add(getResources().getDrawable(R.drawable.player15));
        playerList.add(getResources().getDrawable(R.drawable.player16));
        if (set.topic == 1) {
            for (int i = 0; i < set.top; i++) {//몇강인지에 따라 for drawlist에 추가하는 개수가 달라짐
                int r = random.nextInt(soccerList.size());
                drawList.add(soccerList.get(r));
                soccerList.remove(r);
            }
        }
        if (set.topic == 2) {
            for (int i = 0; i < set.top; i++) {//몇강인지에 따라 for drawlist에 추가하는 개수가 달라짐
                int r = random.nextInt(chamList.size());
                drawList.add(chamList.get(r));
                chamList.remove(r);
            }
        }
        if (set.topic == 3) {
            for (int i = 0; i < set.top; i++) {//몇강인지에 따라 for drawlist에 추가하는 개수가 달라짐
                int r = random.nextInt(playerList.size());
                drawList.add(playerList.get(r));
                playerList.remove(r);
            }
        }
    }
    private void Start() {
        if(set.top==16)Top16();
        if(set.top==8)Top8();
        if(set.top==4)Top4();

    }
    private void top16ListSet() {
        if (first == 0) {
            for (int j = 0; j < 16; j++) {
                top16List.add(drawList.get(j));
                first = 1;
            }
        }
    }

    private void top8ListSet() {
        if (first == 0) {
            for (int j = 0; j < 8; j++) {
                top8List.add(drawList.get(j));
                first = 1;
            }
        }
    }

    private void top4ListSet() {
            if (first == 0) {
                for (int j = 0; j < 4; j++) {
                    top4List.add(drawList.get(j));
                    first = 1;
                }
            }

    }
    private void top2ListSet() {
        if (first == 0) {
            for (int j = 0; j < 2; j++) {
                top2List.add(drawList.get(j));
                first = 1;
            }
        }

    }
    private void top1ListSet() {
        if (first == 0) {
            for (int j = 0; j < 1; j++) {
                top1List.add(drawList.get(j));
                first = 1;
            }
        }

    }
    private void top16Battle() {//화면에 사진을 2개 띄움.
        int r = random.nextInt(top16List.size());
        imgList.get(0).setImageDrawable(top16List.get(r));
        top16List.remove(r);

        r = random.nextInt(top16List.size());
        imgList.get(1).setImageDrawable(top16List.get(r));
        top16List.remove(r);
    }
    private void top8Battle() {//화면에 사진을 2개 띄움.
        int r = random.nextInt(top8List.size());
        imgList.get(0).setImageDrawable(top8List.get(r));
        top8List.remove(r);

        r = random.nextInt(top8List.size());
        imgList.get(1).setImageDrawable(top8List.get(r));
        top8List.remove(r);
    }
    private void top4Battle() {//화면에 사진을 2개 띄움.
        int r = random.nextInt(top4List.size());
        imgList.get(0).setImageDrawable(top4List.get(r));
        top4List.remove(r);

        r = random.nextInt(top4List.size());
        imgList.get(1).setImageDrawable(top4List.get(r));
        top4List.remove(r);
    }
    private void top2Battle() {
        int r = random.nextInt(top2List.size());
        imgList.get(0).setImageDrawable(top2List.get(r));
        top2List.remove(r);

        r = random.nextInt(top2List.size());
        imgList.get(1).setImageDrawable(top2List.get(r));
        top2List.remove(r);
    }
    private void Top16() {
        text.setText("16강");
        if(set.top >= 16&&first==0)top16ListSet();
        top16Battle();
        imgList.get(0).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                top8List.add(imgList.get(0).getDrawable());

                if(top16round<8-1) {
                    top16Battle();
                    top16round++;

                }
                else{
                    Top8();
                }
            }
        });
        imgList.get(1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                top8List.add(imgList.get(1).getDrawable());

                if(top16round<8-1) {
                    top16Battle();
                    top16round++;

                }
                else{
                    Top8();
                }
            }
        });
    }
    private void Top8() {
        text.setText("8강");
        if(set.top >= 8&&first==0)top8ListSet();
        top8Battle();
        imgList.get(0).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                top4List.add(imgList.get(0).getDrawable());

                if(top8round<4-1) {
                    top8Battle();
                    top8round++;

                }
                else{
                    Top4();
                }
            }
        });
        imgList.get(1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                top4List.add(imgList.get(1).getDrawable());

                if(top8round<4-1) {
                    top8Battle();
                    top8round++;

                }
                else{
                    Top4();
                }
            }
        });
    }
    private void Top4() {
        text.setText("4강");
        if(set.top >= 4&&first==0)top4ListSet();
            top4Battle();
            imgList.get(0).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                        top2List.add(imgList.get(0).getDrawable());

                        if(top4round<2-1) {
                        top4Battle();
                        top4round++;

                    }
                    else{
                        Top2();
                    }
                }
            });
            imgList.get(1).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                        top2List.add(imgList.get(1).getDrawable());

                        if(top4round<2-1) {
                            top4Battle();
                            top4round++;

                        }
                        else{
                            Top2();
                        }
                }
            });
        }


    private void Top2() {
        text.setText("결승");
        if(set.top >= 2&&first==0)top2ListSet();
        top2Battle();//화면에 사진을 2개 띄움.
        imgList.get(0).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    top1List.add(imgList.get(0).getDrawable());

                    if(top2round<1-1) {
                        top2Battle();
                        top2round++;

                    }
                    else{
                        Top1();
                    }
            }
        });
        imgList.get(1).setOnClickListener(new View.OnClickListener()  {
            @Override
            public void onClick(View view) {
                    top1List.add(imgList.get(1).getDrawable());

                    if(top2round<1-1) {
                        top2Battle();
                        top2round++;

                    }
                    else{
                        Top1();
                    }
            }
        });
    }
    private void Top1() {
        text.setText("우승!");
        imgList.get(0).setImageDrawable(top1List.get(0));
        imgList.get(1).setVisibility(View.GONE);
        text2.setVisibility(View.GONE);
        button.setVisibility(View.VISIBLE);
    }

}